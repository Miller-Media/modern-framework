<?php
/**
 * Plugin Class File
 *
 * Created:   April 2, 2017
 *
 * @package:  Modern Framework for Wordpress
 * @author:   Kevin Carwile
 * @since:    1.3.12
 */
namespace Modern\Wordpress\Symfony;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Access denied.' );
}

/**
 * Translator Class
 */
class Translator
{
	
}
